<!-- Sidebar -->
<aside class="sidebar">
    <nav class="sidebar-nav">
        <div class="nav-header">
            <h3><i class="fas fa-bars"></i> Menu Utama</h3>
        </div>
        
        <ul class="nav-menu">
            <!-- Menu Dashboard -->
            <li>
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            
            <!-- Menu Laporan (Dropdown) -->
            <li class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle">
                    <i class="fas fa-file-alt"></i>
                    <span>Manajemen Laporan</span>
                    <i class="fas fa-chevron-down dropdown-icon"></i>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="laporan/index.php"><i class="fas fa-list"></i> Daftar Laporan</a></li>
                    <li><a href="laporan/input.php"><i class="fas fa-plus-circle"></i> Input Laporan Baru</a></li>
                    <li><a href="laporan/rekap.php"><i class="fas fa-chart-bar"></i> Rekapitulasi</a></li>
                    <li><a href="laporan/export.php"><i class="fas fa-download"></i> Export Data</a></li>
                </ul>
            </li>
            
            <!-- Menu Kegiatan (Dropdown) -->
            <li class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle">
                    <i class="fas fa-tasks"></i>
                    <span>Kegiatan</span>
                    <i class="fas fa-chevron-down dropdown-icon"></i>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="kegiatan/index.php"><i class="fas fa-calendar-alt"></i> Kalender Kegiatan</a></li>
                    <li><a href="kegiatan/tambah.php"><i class="fas fa-plus"></i> Tambah Kegiatan</a></li>
                    <li><a href="kegiatan/monitoring.php"><i class="fas fa-eye"></i> Monitoring</a></li>
                    <li><a href="kegiatan/evaluasi.php"><i class="fas fa-chart-line"></i> Evaluasi</a></li>
                </ul>
            </li>
            
            <!-- Menu User Management (Dropdown) -->
            <li class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle">
                    <i class="fas fa-users-cog"></i>
                    <span>User Management</span>
                    <i class="fas fa-chevron-down dropdown-icon"></i>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="user-management/index.php"><i class="fas fa-users"></i> Daftar Pengguna</a></li>
                    <li><a href="user-management/tambah.php"><i class="fas fa-user-plus"></i> Tambah Pengguna</a></li>
                    <li><a href="user-management/roles.php"><i class="fas fa-user-tag"></i> Role & Permission</a></li>
                    <li><a href="user-management/log.php"><i class="fas fa-history"></i> Log Aktivitas</a></li>
                </ul>
            </li>
            
            <!-- Menu Lainnya -->
            <li>
                <a href="data-master/index.php" class="nav-link">
                    <i class="fas fa-database"></i>
                    <span>Data Master</span>
                </a>
            </li>
            
            <li>
                <a href="settings.php" class="nav-link">
                    <i class="fas fa-cog"></i>
                    <span>Pengaturan</span>
                </a>
            </li>
            
            <li class="logout">
                <a href="logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </nav>
</aside>