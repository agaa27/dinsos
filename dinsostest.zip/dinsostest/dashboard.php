<?php
require_once 'config/database.php';
require_once 'includes/header.php';
?>

<div class="main-content">
    <div class="page-header">
        <h2><i class="fas fa-home"></i> Dashboard</h2>
        <p>Selamat datang di Sistem Informasi Dinas Sosial & PM Kota Tarakan</p>
    </div>
    
    <div class="dashboard-cards">
        <div class="card">
            <div class="card-icon bg-primary">
                <i class="fas fa-file-alt"></i>
            </div>
            <div class="card-content">
                <h3>Total Laporan</h3>
                <p class="card-number">158</p>
                <a href="laporan/index.php" class="card-link">Lihat Detail →</a>
            </div>
        </div>
        
        <div class="card">
            <div class="card-icon bg-success">
                <i class="fas fa-tasks"></i>
            </div>
            <div class="card-content">
                <h3>Kegiatan Aktif</h3>
                <p class="card-number">23</p>
                <a href="kegiatan/index.php" class="card-link">Lihat Detail →</a>
            </div>
        </div>
        
        <div class="card">
            <div class="card-icon bg-warning">
                <i class="fas fa-users"></i>
            </div>
            <div class="card-content">
                <h3>Pengguna Sistem</h3>
                <p class="card-number">48</p>
                <a href="user-management/index.php" class="card-link">Lihat Detail →</a>
            </div>
        </div>
        
        <div class="card">
            <div class="card-icon bg-danger">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="card-content">
                <h3>Kinerja Bulan Ini</h3>
                <p class="card-number">92%</p>
                <a href="#" class="card-link">Lihat Detail →</a>
            </div>
        </div>
    </div>
    
    <div class="dashboard-content">
        <div class="row">
            <div class="col-8">
                <div class="card">
                    <div class="card-header">
                        <h3>Laporan Terbaru</h3>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Judul Laporan</th>
                                    <th>Tanggal</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Bantuan Sosial Tunai Tahap 3</td>
                                    <td>15 Jan 2024</td>
                                    <td><span class="badge badge-success">Selesai</span></td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Pemberdayaan UMKM Kelurahan...</td>
                                    <td>14 Jan 2024</td>
                                    <td><span class="badge badge-warning">Proses</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="col-4">
                <div class="card">
                    <div class="card-header">
                        <h3>Kegiatan Mendatang</h3>
                    </div>
                    <div class="card-body">
                        <ul class="activity-list">
                            <li>
                                <i class="fas fa-calendar-day"></i>
                                <div>
                                    <strong>Rapat Koordinasi</strong>
                                    <p>17 Jan 2024, 09:00 WITA</p>
                                </div>
                            </li>
                            <li>
                                <i class="fas fa-calendar-day"></i>
                                <div>
                                    <strong>Monitoring PKH</strong>
                                    <p>18 Jan 2024, 08:00 WITA</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>